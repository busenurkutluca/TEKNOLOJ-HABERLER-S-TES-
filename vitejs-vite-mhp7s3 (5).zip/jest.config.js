module.exports = {
  verbose: false,
  watchPathIgnorePatterns: ['./resultz.json'],
};
